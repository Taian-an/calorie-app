const express  = require('express');
const cors     = require('cors');
const axios    = require('axios');
const multer   = require('multer');
const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { THAI_FOODS } = require('./thai-foods');
require('dotenv').config();

const app    = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(cors());
app.use(express.json());

const GOOGLE_VISION_API_KEY = process.env.GOOGLE_VISION_API_KEY;
const USDA_KEY = process.env.USDA_API_KEY || 'DEMO_KEY';
const JWT_SECRET = process.env.JWT_SECRET;

/* ===== MongoDB（與管理後台共用 calorieDB）===== */
mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/calorieDB')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connect failed:', err.message));

// users collection 與 SP1 後台共用，後台的使用者管理頁會直接看到 App 註冊的帳號
const User = mongoose.model('User', new mongoose.Schema({
  userId:       String, // 後台顯示用編號 u1001 起
  email:        { type: String, unique: true, sparse: true },
  passwordHash: String,
  name:         String,
  avatarKey:    String,
  gender:       String,
  age:          Number,
  height:       Number,
  weight:       Number,
  activity:     String,
  goal:         String,
  bmr:          Number,
  tdee:         Number,
  target:       Number,
  status:       { type: String, default: 'Active' },
}, { timestamps: true }));

const dailyLogSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, required: true },
  date:   { type: String, required: true }, // YYYY-MM-DD
  weight: Number,
  target: Number,
  meals:  [{
    name: String, energy: Number, protein: Number, carbs: Number, fat: Number,
    mealType: String, time: Number,
  }],
}, { timestamps: true });
dailyLogSchema.index({ userId: 1, date: 1 }, { unique: true });
const DailyLog = mongoose.model('DailyLog', dailyLogSchema);

// 食物資料庫：thai-foods 遷移進來 + USDA 查詢結果快取 + 之後管理員手動新增
const Food = mongoose.model('Food', new mongoose.Schema({
  name:    { type: String, required: true },
  aliases: [String], // 全小寫
  energy:  Number, protein: Number, carbs: Number, fat: Number,
  source:  { type: String, enum: ['thai', 'usda', 'admin'], default: 'admin' },
}, { timestamps: true }));

// 每次 AI 辨識的歷史（登入者附 userId），供除錯、成本追蹤與之後的個人歷史
const Analysis = mongoose.model('Analysis', new mongoose.Schema({
  userId:      { type: mongoose.Schema.Types.ObjectId, default: null },
  candidates:  [String],
  matchedName: String,
  source:      String, // 'db' | 'usda'
  result:      { name: String, energy: Number, protein: Number, carbs: Number, fat: Number },
}, { timestamps: true }));

// 啟動時一次性遷移：foods 空的話把泰式對照表種進去
async function seedFoods() {
  try {
    if (await Food.countDocuments() === 0) {
      await Food.insertMany(THAI_FOODS.map(f => ({ ...f, source: 'thai' })));
      console.log(`Seeded ${THAI_FOODS.length} thai foods into DB`);
    }
  } catch (err) {
    console.error('[seedFoods]', err.message);
  }
}
mongoose.connection.once('open', seedFoods);

// 沿用原本 thai-foods 的雙向比對邏輯，但改吃資料庫（foods 量小，全撈進記憶體比對）
function matchFood(foods, description) {
  const normalized = description.toLowerCase().trim();
  if (normalized.length < 3) return null;
  for (const entry of foods) {
    const names = [...(entry.aliases ?? []), entry.name.toLowerCase()];
    const matched = names.some(alias =>
      normalized.includes(alias) || (normalized.length >= 4 && alias.includes(normalized))
    );
    if (matched) return entry;
  }
  return null;
}

/* ===== Auth ===== */
const PROFILE_FIELDS = ['name', 'avatarKey', 'gender', 'age', 'height', 'weight', 'activity', 'goal', 'bmr', 'tdee', 'target'];

function publicProfile(user) {
  const out = { email: user.email };
  for (const f of PROFILE_FIELDS) if (user[f] != null) out[f] = user[f];
  return out;
}

function signToken(user) {
  return jwt.sign({ uid: user._id.toString() }, JWT_SECRET, { expiresIn: '90d' });
}

function requireAuth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer /, '');
  try {
    req.uid = jwt.verify(token, JWT_SECRET).uid;
    next();
  } catch {
    res.status(401).json({ error: 'Unauthorized' });
  }
}

// 有帶 token 就解析、沒帶也放行（/analyze 用：匿名可用，登入者記到個人歷史）
function optionalAuth(req, _res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer /, '');
  try { req.uid = jwt.verify(token, JWT_SECRET).uid; } catch { req.uid = null; }
  next();
}

// 註冊：可同時帶 profile（把本地資料一起上傳）
app.post('/auth/register', async (req, res) => {
  try {
    const { email, password, profile } = req.body;
    if (!email?.trim() || !password || password.length < 4) {
      return res.status(400).json({ error: 'Invalid email or password (min 4 chars)' });
    }
    if (await User.findOne({ email: email.trim().toLowerCase() })) {
      return res.status(409).json({ error: 'Email already registered' });
    }
    const count = await User.countDocuments();
    const user = await User.create({
      userId: 'u' + (1001 + count),
      email: email.trim().toLowerCase(),
      passwordHash: await bcrypt.hash(password, 10),
      ...(profile ?? {}),
    });
    res.json({ token: signToken(user), profile: publicProfile(user) });
  } catch (err) {
    console.error('[register]', err.message);
    res.status(500).json({ error: 'Register failed' });
  }
});

app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: (email ?? '').trim().toLowerCase() });
    if (!user?.passwordHash || !(await bcrypt.compare(password ?? '', user.passwordHash))) {
      return res.status(401).json({ error: 'Wrong email or password' });
    }
    res.json({ token: signToken(user), profile: publicProfile(user) });
  } catch (err) {
    console.error('[login]', err.message);
    res.status(500).json({ error: 'Login failed' });
  }
});

/* ===== Profile ===== */
app.get('/me', requireAuth, async (req, res) => {
  const user = await User.findById(req.uid);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(publicProfile(user));
});

app.put('/me', requireAuth, async (req, res) => {
  const patch = {};
  for (const f of PROFILE_FIELDS) if (req.body[f] !== undefined) patch[f] = req.body[f];
  const user = await User.findByIdAndUpdate(req.uid, patch, { new: true });
  res.json(publicProfile(user));
});

/* ===== Daily Logs 同步 ===== */
// 取回所有（或某區間的）日誌，回傳格式與 App 本地儲存一致：{ "YYYY-MM-DD": {...} }
app.get('/logs', requireAuth, async (req, res) => {
  const query = { userId: req.uid };
  if (req.query.from || req.query.to) {
    query.date = {};
    if (req.query.from) query.date.$gte = req.query.from;
    if (req.query.to)   query.date.$lte = req.query.to;
  }
  const logs = await DailyLog.find(query).lean();
  const out = {};
  for (const l of logs) {
    out[l.date] = {
      weight: l.weight, target: l.target,
      meals: (l.meals ?? []).map(({ name, energy, protein, carbs, fat, mealType, time }) =>
        ({ name, energy, protein, carbs, fat, mealType, time })),
    };
  }
  res.json(out);
});

// 整天覆寫（最後寫入者贏），App 每次記錄後呼叫
app.put('/logs/:date', requireAuth, async (req, res) => {
  const { date } = req.params;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({ error: 'Bad date' });
  const { weight, target, meals } = req.body ?? {};
  await DailyLog.updateOne(
    { userId: req.uid, date },
    { $set: { weight, target, meals: meals ?? [] } },
    { upsert: true }
  );
  res.json({ ok: true });
});

// Vision API 常回傳這類空泛詞，對查營養資料庫沒有幫助，直接跳過
const GENERIC_TERMS = new Set([
  'food', 'dish', 'cuisine', 'ingredient', 'recipe', 'meal', 'comfort food',
  'produce', 'natural foods', 'staple food', 'finger food', 'baked goods',
  'fast food', 'junk food', 'side dish', 'garnish', 'tableware', 'plate',
  'cookware and bakeware', 'still life photography', 'superfood',
  'packaging and labeling', 'logo', 'convenience food', 'label',
]);

// 包裝食品上常見的印刷文字，不是產品名稱，OCR 抓到直接跳過
const OCR_STOPWORDS = new Set([
  'ingredients', 'nutrition', 'facts', 'serving', 'size', 'calories',
  'net', 'wt', 'weight', 'best', 'before', 'use', 'by', 'exp', 'contains',
  'total', 'fat', 'sodium', 'protein', 'carbohydrate', 'sugars', 'daily',
  'value', 'per', 'made', 'in', 'product', 'of', 'distributed', 'www',
]);

// 從包裝上 OCR 出來的文字裡挑出可能是產品名稱的行（通常是最上面幾行有意義的文字）
function extractOcrCandidates(fullTextAnnotation) {
  const text = fullTextAnnotation?.text ?? '';
  return text
    .split('\n')
    .map(line => line.trim())
    .filter(line => {
      if (line.length < 3 || line.length > 30) return false;
      if (!/[a-zA-Z]/.test(line)) return false;
      const words = line.toLowerCase().split(/\s+/);
      return !words.every(w => OCR_STOPWORDS.has(w));
    })
    .slice(0, 3)
    .map(line => ({ description: line, score: 0.99 }));
}

// POST /analyze — 接收圖片，回傳食物名稱 + 營養素
app.post('/analyze', optionalAuth, upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded' });

  try {
    // 1. Google Vision API 食物辨識
    // LABEL_DETECTION 常給空泛詞（"Food"、"Dish"），WEB_DETECTION 的 webEntities
    // 是拿圖片去網路比對相似圖片得出的實體，通常會給更具體的菜名（例如 "Margherita pizza"）
    const visionRes = await axios.post(
      `https://vision.googleapis.com/v1/images:annotate?key=${GOOGLE_VISION_API_KEY}`,
      {
        requests: [
          {
            image: { content: req.file.buffer.toString('base64') },
            features: [
              { type: 'LABEL_DETECTION', maxResults: 10 },
              { type: 'WEB_DETECTION', maxResults: 10 },
              { type: 'TEXT_DETECTION' },
            ],
          },
        ],
      }
    );

    const visionData = visionRes.data.responses?.[0] ?? {};
    const webEntities = (visionData.webDetection?.webEntities ?? [])
      .filter(e => e.description && e.score);
    const labels = visionData.labelAnnotations ?? [];
    const ocrCandidates = extractOcrCandidates(visionData.fullTextAnnotation);

    // 包裝上讀到的文字最可能就是實際產品名稱，優先於 web/label 的籠統描述嘗試
    const candidates = [
      ...ocrCandidates,
      ...[...webEntities, ...labels]
        .filter(c => !GENERIC_TERMS.has(c.description.toLowerCase()))
        .sort((a, b) => b.score - a.score),
    ];

    console.log('[Vision] candidates:', candidates.map(c => `${c.description} (${c.score})`).join(', '));

    if (!candidates.length) return res.status(502).json({ error: 'No result from Vision API' });

    // 2. 依信心分數高到低，依序比對：先查自家食物資料庫（含泰式對照表 + 過去 USDA 快取），
    //    沒有再退回去查 USDA，查到就快取進資料庫，下次同樣的食物不用再打 USDA
    const foods = await Food.find().lean();
    let top = null;
    let result = null;
    let source = null;
    for (const candidate of candidates) {
      const dbMatch = matchFood(foods, candidate.description);
      if (dbMatch) {
        console.log('[FoodDB] matched:', candidate.description, '->', dbMatch.name);
        top = candidate;
        result = dbMatch;
        source = 'db';
        break;
      }

      const usdaRes = await axios.get('https://api.nal.usda.gov/fdc/v1/foods/search', {
        params: { query: candidate.description, api_key: USDA_KEY, pageSize: 1 },
      });
      const food = usdaRes.data.foods?.[0];
      console.log('[USDA] tried:', candidate.description, '-> match:', food?.description ?? 'none');
      if (food) {
        const get = name => food.foodNutrients.find(n => n.nutrientName === name)?.value ?? 0;
        top = candidate;
        source = 'usda';
        result = {
          name:    food.description,
          energy:  get('Energy'),
          protein: get('Protein'),
          carbs:   get('Carbohydrate, by difference'),
          fat:     get('Total lipid (fat)'),
        };
        // 快取進食物資料庫（用辨識詞當 alias，下次直接命中）
        Food.updateOne(
          { name: result.name },
          {
            $setOnInsert: { energy: result.energy, protein: result.protein, carbs: result.carbs, fat: result.fat, source: 'usda' },
            $addToSet: { aliases: candidate.description.toLowerCase() },
          },
          { upsert: true }
        ).catch(err => console.warn('[Food cache]', err.message));
        break;
      }
    }

    if (!result) return res.status(502).json({ error: 'No food data found' });

    // 辨識歷史（登入者附 userId）
    Analysis.create({
      userId: req.uid,
      candidates: candidates.slice(0, 5).map(c => c.description),
      matchedName: result.name,
      source,
      result: { name: result.name, energy: result.energy, protein: result.protein, carbs: result.carbs, fat: result.fat },
    }).catch(err => console.warn('[Analysis]', err.message));

    res.json({
      name:       result.name,
      confidence: Math.round(top.score * 100),
      energy:     result.energy,
      protein:    result.protein,
      carbs:      result.carbs,
      fat:        result.fat,
    });
  } catch (err) {
    console.error('[analyze] failed:', err.response?.data ? JSON.stringify(err.response.data) : err.message);
    res.status(500).json({ error: 'Analysis failed' });
  }
});

/* ===== 食物搜尋與辨識歷史 ===== */
app.get('/foods/search', async (req, res) => {
  const q = (req.query.q ?? '').trim();
  if (q.length < 2) return res.json([]);
  const regex = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  const foods = await Food.find({ $or: [{ name: regex }, { aliases: regex }] })
    .limit(20)
    .select('name energy protein carbs fat source')
    .lean();
  res.json(foods);
});

app.get('/analyses', requireAuth, async (req, res) => {
  const items = await Analysis.find({ userId: req.uid })
    .sort({ createdAt: -1 })
    .limit(50)
    .select('matchedName source result createdAt')
    .lean();
  res.json(items);
});

// Health check
app.get('/health', (_, res) => res.json({ status: 'ok' }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
